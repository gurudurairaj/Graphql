// RESOLVER
const { getAllEmployees, getEmployeeById,
  getEmployeesByCompanyId, getEmployeesByTechnologyId,
  addANewEmployee, mapTechEmpComp, unMapTechEmpComp } = require('./db/employee');

const { getAllCompanies, getCompanyById,
  getCompaniesByTechnologyId, getACompanyByEmployeeId,
  addANewCompany } = require('./db/company');

const { getAllTechnologies, getTechnologyById,
  getTechnologiesByCompanyId, getTechnologiesByEmployeeId,
  addANewTechnology } = require('./db/technology');

const { PubSub, withFilter } = require('apollo-server-express');
const pubsub = new PubSub();

const resolvers = {
  Subscription: {
    getLuckyNo: {
      subscribe: () => pubsub.asyncIterator(['GET_LUCKY_NO']),
      // may be used for data transformation
      resolve: (payload) => { 
        console.log("Subscription Resolved:: getLuckyNo", payload);
        return payload.getLuckyNo * 100;
      }
    },
    employeeAdded: {
      // subscribe: () => pubsub.asyncIterator('EMP_ADDED'),
      subscribe: withFilter(
        () => pubsub.asyncIterator('EMP_ADDED'),
        (payload, variables) => {
          // based on some logic return true or false
          // incoming payload and incoming subscription field variables can be used to decide true or false.
          // for now, a very simple example:
          console.log("Inside employeeAdded subscription:: withFilter");
          const today = new Date(); 
          today.setHours(0,0,0,0);
          if (today.getDay() === 6 || today.getDay() === 7 ) {
            console.log("Not allowed on Week-ends");
            return false;
          } 
          console.log("Allowed on Week-days");
          return true;
        },
      ),
      // may be used for data transformation
      resolve: (payload) => {
        console.log("Subscription Resolved:: EMP_ADDED", payload);
        return payload;
      }
    }
  },

  Query: {
    hello: () => "Hello GraphQL world!",
    getSingleLuckyNo: () => Math.round(Math.random() * 10),
    employees: () => getAllEmployees(),
    employeeById: (parent, args, context, info) => getEmployeeById(args.id),
    companies: () => getAllCompanies(),
    companyById: (parent, args, context, info) => getCompanyById(args.id),
    technologies: () => getAllTechnologies(),
    technologyById: (parent, args, context, info) => getTechnologyById(args.id),
  }, 

  Mutation: {
    generateLuckyNumbers: (parent, args, context, info) => genLucky(),

    addTechnology: (parent, args, context, info) => addANewTechnology(args),
    addCompany: (parent, args, context, info) => addANewCompany(args),
    addEmployee: (parent, args, context, info) => addANewEmployee(args, pubsub),

    mapTechEmpComp: (parent, args, context, info) => mapTechEmpComp(args),
    unMapTechEmpComp: (parent, args, context, info) => unMapTechEmpComp(args),
  },

  Employee: {
    fullName: (parent, args, context, info) => parent.firstName + ' ' + parent.lastName,
    company: (parent, args, context, info) => getACompanyByEmployeeId(parent.id),
    technologies: (parent, args, context, info) => getTechnologiesByEmployeeId(parent.id),
  },

  Company: {
    employees: (parent, args, context, info) => getEmployeesByCompanyId(parent.id),
    technologies: (parent, args, context, info) => getTechnologiesByCompanyId(parent.id),
  },

  Technology: {
    employees: (parent, args, context, info) => getEmployeesByTechnologyId(parent.id),
    companies: (parent, args, context, info) => getCompaniesByTechnologyId(parent.id),
  },
};

function genLucky() {
  const aLuckyNo = Math.round(Math.random() * 10)
  pubsub.publish('GET_LUCKY_NO', { getLuckyNo: aLuckyNo });
  setTimeout(genLucky, 1000);
  return aLuckyNo;
}

module.exports = resolvers;