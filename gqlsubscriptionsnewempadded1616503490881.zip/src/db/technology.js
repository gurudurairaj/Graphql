// Importing the data sources
const technologyArray = require('../data-source/technology.json');
const employeeArray = require('../data-source/employee.json');

exports.getAllTechnologies = () => {
  console.log("TECH DATA: getAllTechnologies:");
  //return technologyArray;
  return new Promise(res => setTimeout(() => res(technologyArray), 1000));

}

exports.getTechnologyById = (technologyId) => {
  console.log("TECH DATA: getTechnologyById:", technologyId);
  //return technologyArray.find(_ => _.id === technologyId)
  return new Promise(res => setTimeout(() => res(technologyArray.find(_ => _.id === technologyId)), 1000));
}

exports.getTechnologiesByCompanyId = (companyId) => {
  console.log("TECH DATA: getTechnologiesByCompanyId:", companyId);
  const uniqueTechArray = new Set();
  employeeArray
    .filter(_ => _.companyId === companyId)
    .forEach(empInCompany => empInCompany.technologyIds.forEach(
      techId => uniqueTechArray.add(techId)
    ));
  const technologiesByCompanyId = [...uniqueTechArray].map(_ => technologyArray.find(__ => __.id === _));
  //return technologiesByCompanyId;
  return new Promise(res => setTimeout(() => res(technologiesByCompanyId), 1000));
}

exports.getTechnologiesByEmployeeId = (empId) => {
  console.log("TECH DATA: getTechnologiesByEmployeeId:", empId);
  const technologiesByEmployeeId = employeeArray
    .find(_ => _.id === empId).technologyIds
    .map(_ => technologyArray.find(__ => __.id === _));
  //return technologiesByEmployeeId;
  return new Promise(res => setTimeout(() => res(technologiesByEmployeeId), 1000));
}

exports.addANewTechnology = (newTechObj) => {
  console.log();
  console.log("TECH DATA: addANewTechnology:", newTechObj);
  isNewTech(newTechObj);
  newTechObj.id = generateId('T', technologyArray);
  technologyArray.push(newTechObj);
  console.log("Technology added!");
  //return technologyArray.find(_ => _.id === newTechObj.id);
  return new Promise(res => setTimeout(() => res(technologyArray.find(_ => _.id === newTechObj.id)), 1000));

}

function isNewTech(newTechObj) {
  console.log("Checking: isNewTech");
  if (technologyArray.find(_ => _.name === newTechObj.name)) {
    console.log("No! couldn't add the technology");
    throw new Error("Technology already existing!");
  }
  console.log("Yes!");
}

function generateId(strParam, dataArray) {
  return strParam + (Math.max(...dataArray.map(_ => parseInt(_.id.substr(1)))) + 1)
}
