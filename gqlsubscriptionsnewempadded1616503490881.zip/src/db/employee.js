const employeeArray = require('../data-source/employee.json');

exports.getAllEmployees = () => {
  console.log("EMP DATA: getAllEmployees:");
  // could have simply returned ==> 
  //return employeeArray

  // BUT :: simulating a server-side delay, returning a Promise that resolves after 1 sec!
  return new Promise(res => setTimeout(() => res(employeeArray), 1000));

}

exports.getEmployeeById = (empId) => {
  console.log("EMP DATA: getEmployeeById:", empId);
  // return employeeArray.find(_ => _.id === empId)
  // simulating a server delay, returning a Promise that resolves after 1 sec!
  const foundEmp = employeeArray.find(_ => _.id === empId);
  return new Promise((res,rej) => {
    setTimeout(() => {
      foundEmp ? res(foundEmp) : rej(new Error('Employee details not Found'));
    }, 1000);
  });

}

exports.getEmployeesByCompanyId = (companyId) => {
  console.log("EMP DATA: getEmployeesByCompanyId:", companyId);
  // return employeeArray.filter(_ => _.companyId === companyId);
  // simulating a server delay, returning a Promise that resolves after 1 secs!
  return new Promise(res => setTimeout(() => res(employeeArray.filter(_ => _.companyId === companyId)), 1000));
}

exports.getEmployeesByTechnologyId = (technologyId) => {
  console.log("EMP DATA: getEmployeesByTechnologyId:", technologyId);
  //return employeeArray.filter(_ => _.technologyIds.includes(technologyId));
  return new Promise(res => setTimeout(() => res(employeeArray.filter(_ => _.technologyIds.includes(technologyId))), 1000));
}

exports.addANewEmployee = (newEmpObj, pubsub) => {
  console.log();
  console.log("EMP DATA: addANewEmployee:", newEmpObj);
  isNewEmp(newEmpObj);

  newEmpObj.id = generateId('E', employeeArray);
  newEmpObj.companyId = "";
  newEmpObj.technologyIds = [];

  employeeArray.push(newEmpObj);
  console.log("Employee added!");
  // to simulate a server delay
  // return employeeArray.find(_ => _.id === newEmpObj.id);
  return new Promise(res => setTimeout(() => {
    // publishing the updated array again // too expensive!
    //pubsub.publish('subscriptionEmployees', employeeArray); 
    const newlyAdded = employeeArray.find(_ => _.id === newEmpObj.id);
    // should only publish the newlyAdded employee!
    pubsub.publish('EMP_ADDED', newlyAdded); 
// pubsub.publish('EMP_ADDED', {
//   id: "E6666", 
//   firstName:"John", 
//   lastName:"Doe", 
//   jobLevel:3
// }); 
    res(newlyAdded);
  }, 1000)); 
}

function isNewEmp(newEmpObj) {
  console.log("Checking: isNewEmp");
  if (employeeArray.find(_ => _.firstName === newEmpObj.firstName && _.lastName === newEmpObj.lastName)) {
    console.log("No! couldn't add the employee");
    throw new Error("Employee already existing!");
  }
  console.log("Yes!");
}

function generateId(strParam, dataArray) {
  return strParam + (Math.max(...dataArray.map(_ => parseInt(_.id.substr(1)))) + 1)
}

exports.mapTechEmpComp = ({ techId, empId, compId }) => {
  console.log();
  console.log("EMP DATA: mapTechEmpComp:", techId, empId, compId);
  if (techId && empId && compId) {
    throw new Error('Cannot work with all three entities together!')
  }
  const foundEmp = employeeArray.find(_ => _.id === empId);
  if (!foundEmp) {
    throw new Error('Cannot map Technologies and Companies, without an Employee!');
  }
  if (techId) {
    if (!foundEmp.technologyIds.includes(techId)) {
      foundEmp.technologyIds.push(techId);
    }
  }
  else if (compId) {
    foundEmp.companyId = compId;
  }
  //return foundEmp;
  return new Promise(res => setTimeout(()=> res(foundEmp), 1000));
}

exports.unMapTechEmpComp = ({ techId, empId, compId }) => {
  console.log();
  console.log("EMP DATA: 666-555 UnMapTechEmpComp:", techId, empId, compId);

  if (techId && empId && compId) {
    throw new Error('Cannot work with all three entities together!')
  }
  const foundEmp = employeeArray.find(_ => _.id === empId);
  if (!foundEmp) {
    throw new Error('Cannot Un-Map Technologies and Companies, without an Employee');
  }
  if (techId) {
    foundEmp.technologyIds = foundEmp.technologyIds.filter(_ => _ !== techId);
  }
  else if (compId) {
    foundEmp.companyId = null;
  }
  //return foundEmp;
  return new Promise(res => setTimeout(()=> res(foundEmp), 1000));
}

