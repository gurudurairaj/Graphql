const companyArray = require('../data-source/company.json');
const employeeArray = require('../data-source/employee.json');

exports.getAllCompanies = () => {
  console.log("COMP DATA: getAllCompanies:");
  //return companyArray;
  return new Promise(res => setTimeout(() => res(companyArray), 1000));
}

exports.getCompanyById = (companyId) => {
  console.log("COMP DATA: getCompanyById:", companyId);
  //return companyArray.find(_ => _.id === companyId)
  return new Promise(res => setTimeout(() => res(companyArray.find(_ => _.id === companyId)), 1000));
}

exports.getCompaniesByTechnologyId = (technologyId) => {
  console.log("COMP DATA: getCompaniesByTechnologyId:", technologyId);
  const companiesByTechnologyId = [...new Set(
    employeeArray
      .filter(_ => _.technologyIds.includes(technologyId))
      .map(foundEmp => foundEmp.companyId)
    ) 
  ]
  .map(aUniqueCompId => companyArray.find(_ => _.id === aUniqueCompId));
  //return companiesByTechnologyId;
  return new Promise(res => setTimeout(() => res(companiesByTechnologyId), 1000));
}

exports.getACompanyByEmployeeId = (empId) => {
  console.log("COMP DATA: getACompanyByEmployeeId:", empId);
  const aCompanyByEmployeeId = companyArray.find( _ => _.id === employeeArray.find(_=>_.id === empId).companyId );
  // return aCompanyByEmployeeId;
  return new Promise(res => setTimeout(() => res(aCompanyByEmployeeId), 1000));
}

exports.addANewCompany = (newCompObj) => {
  console.log();
  console.log("COMP DATA: addANewCompany:", newCompObj);
  isNewComp(newCompObj);
  newCompObj.id = generateId('C', companyArray);
  companyArray.push(newCompObj);
  console.log("Company added!");
  //return companyArray.find(_ => _.id === newCompObj.id);
  return new Promise(res => setTimeout(() => res(companyArray.find(_ => _.id === newCompObj.id)), 1000));
}

function isNewComp(newCompObj) {
  console.log("Checking: isNewComp");
  if (companyArray.find(_ => _.name === newCompObj.name)) {
    console.log("No! couldn't add the company");
    throw new Error("Company already existing!");
  }
  console.log("Yes!");
}

function generateId(strParam, dataArray) {
  return strParam + (Math.max(...dataArray.map(_ => parseInt(_.id.substr(1)))) + 1)
}