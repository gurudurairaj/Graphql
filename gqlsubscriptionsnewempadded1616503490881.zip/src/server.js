const cors = require('cors')
const express = require('express');

// 0. Setting up GraphQL
const { ApolloServer, makeExecutableSchema } = require('apollo-server-express');

// 0. Setting up Subscriptions
const { SubscriptionServer } = require('subscriptions-transport-ws');
const { execute, subscribe } = require('graphql');
const { createServer } = require('http');

const typeDefs = require("./schema");
const resolvers = require("./resolver");

//////////////////////////////IMPORTS END/////////////////////////////////

const port = process.env.PORT || 4000
const expressServer = express()

// 0. Register Express middlewares
expressServer.use(cors());
expressServer.use('/graphql', express.json());

const schema = makeExecutableSchema({ typeDefs, resolvers });

// 4. Initialize the ApolloExpressServer 
const apolloServer = new ApolloServer({
  schema,
  subscriptions: {
    path: '/subscriptions',
  },
});
apolloServer.applyMiddleware({ app: expressServer });

const httpServer = createServer(expressServer);

httpServer.listen({ port }, () => {

  // Set up the WebSocket for handling GraphQL subscriptions
  // 1. Built-In "installSubscriptionHandlers"
  // apolloServer.installSubscriptionHandlers(httpServer);
  // 2. Or SetUp Manually

  new SubscriptionServer({
    execute,
    subscribe,
    schema,
    onConnect: (connectionParams, webSocket, context) => {
      console.log("Client Connected to WS server");
      //console.log(connectionParams, webSocket, context);
    },
    onDisconnect: (connectionParams, webSocket, context) => {
      console.log("Client Disconnected to WS server");
      //console.log(connectionParams, webSocket, context);
    }
  },
    {
      server: httpServer,
      path: '/subscriptions',
    },
  );

  console.log(`GQL Queries and Mutation @ http://localhost:${port}${apolloServer.graphqlPath}`)
  console.log(`Subscriptions ready @ ws://localhost:${port}${apolloServer.subscriptionsPath}`)
});