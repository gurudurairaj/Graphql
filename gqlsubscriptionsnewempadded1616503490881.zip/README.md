npm init --yes

## Apollo Server and Express Related
npm i --save apollo-server-express graphql express nodemon

GQL Queries and Mutation @ http://localhost:4000/graphql
GQL Subscriptions @ ws://localhost:4000/subscriptions