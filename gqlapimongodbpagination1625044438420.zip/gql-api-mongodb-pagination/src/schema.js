// SCHEMA
const { gql } = require('apollo-server-express');

const typeDefs = gql`

  type Query {
    hello: String
    getRandomNo: Int
    employees(offset:Int,limit:Int): [Employee]
    employeeById (id:ID!): Employee
    setupDB:String
    companies(offset:Int,limit:Int): [Company]
    companyById (id:ID!): Company
    
    technologies: [Technology]
    technologyById (id:ID!) : Technology
  }

  type Mutation {
    addTechnology(name:String! description: String!): Technology!
    addCompany(name:String! description: String!): Company!
    addEmployee(firstName:String! lastName:String! jobLevel:Int!) : Employee!
    
    mapTechEmpComp(techId: ID empId: ID compId: ID) : Employee! 
    unMapTechEmpComp(techId: ID empId: ID compId: ID): Employee!
  }

  type Technology {
    id: ID!
    name: String
    description: String
    companies: [Company]
    employees: [Employee]
  }

  type Employee {
    id: ID!
    firstName: String
    lastName: String
    body:String
    jobLevel: Int
    fullName: String
    company: Company
    technologies: [Technology]
  }

  type Company {
    id: ID!
    name: String
    description: String
    employees: [Employee]
    technologies: [Technology]
  }
`;

module.exports = typeDefs;