// RESOLVER
const axios = require("axios");
const {
  getAllEmployees,
  getEmployeeById,
  getEmployeesByCompanyId,
  getEmployeesByTechnologyId,
  addANewEmployee,
  mapTechEmpComp,
  unMapTechEmpComp,
  setDbCollections,
} = require("./db/employee");

const {
  getAllCompanies,
  getCompanyById,
  getCompaniesByTechnologyId,
  getACompanyByEmployeeId,
  addANewCompany,
} = require("./db/company");

const {
  getAllTechnologies,
  getTechnologyById,
  getTechnologiesByCompanyId,
  getTechnologiesByEmployeeId,
  addANewTechnology,
} = require("./db/technology");

const resolvers = {
  Query: {
    hello: () => "Hello GraphQL world!",
    getRandomNo: () => Math.round(Math.random() * 10),
    employees: (parent, args, context, info) => getAllEmployees(args),
    employeeById: (parent, args, context, info) => getEmployeeById(args.id),
    setupDB: () => setDbCollections(),
    companies: (parent, args, context, info) => getAllCompanies(args),
    companyById: (parent, args, context, info) => getCompanyById(args.id),

    technologies: () => getAllTechnologies(),
    technologyById: (parent, args, context, info) => getTechnologyById(args.id),
  },

  Mutation: {
    addTechnology: (parent, args, context, info) => addANewTechnology(args),
    addCompany: (parent, args, context, info) => addANewCompany(args),
    addEmployee: (parent, args, context, info) => addANewEmployee(args),
    mapTechEmpComp: (parent, args, context, info) => mapTechEmpComp(args),
    unMapTechEmpComp: (parent, args, context, info) => unMapTechEmpComp(args),
  },

  Employee: {
    fullName: (parent, args, context, info) =>
      parent.firstName + " " + parent.lastName,
    company: (parent, args, context, info) =>
      getACompanyByEmployeeId(parent.id),
    technologies: (parent, args, context, info) =>
      getTechnologiesByEmployeeId(parent.id),
    body: (parent, args, context, info) => {
      const id = parent.id[parent.id.length - 1];

      return axios
        .get("https://jsonplaceholder.typicode.com/posts/" + id)
        .then((response) => {
          return response.data.body;
        });
    },
  },

  Company: {
    employees: (parent, args, context, info) =>
      getEmployeesByCompanyId(parent.id),
    technologies: (parent, args, context, info) =>
      getTechnologiesByCompanyId(parent.id),
  },

  Technology: {
    employees: (parent, args, context, info) =>
      getEmployeesByTechnologyId(parent.id),
    companies: (parent, args, context, info) =>
      getCompaniesByTechnologyId(parent.id),
  },
};

module.exports = resolvers;

/*
Note − We can replace the company.json and employee.json with a RESTful API call,
to retrieve employee/company data or even a real database like MySQL or MongoDB.

HENCE: GraphQL becomes a thin wrapper around our original application layer to improve performance.
*/
