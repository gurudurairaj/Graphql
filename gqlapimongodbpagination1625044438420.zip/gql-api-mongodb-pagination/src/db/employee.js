const employeeArray = require('../data-source/employee.json');
const companyArray = require("../data-source/company.json");
const technologyArray = require("../data-source/technology.json");
const EmployeeModel = require("./connection").getEmployeeModel;
const CompanyModel = require("./connection").getCompanyModel;
const TechnologyModel = require("./connection").getTechnologyModel;
const { mongo } = require('mongoose');

exports.setDbCollections = async () => {
  const empModel = await EmployeeModel();
  const techModel = await TechnologyModel();
  const cmpModel = await CompanyModel();
  await empModel.deleteMany({});
  await cmpModel.deleteMany({});
  await techModel.deleteMany({});

  const insertedEmp = await empModel.insertMany(
    employeeArray
  );
  const insertedCompany = await cmpModel.insertMany(
    companyArray
  );
  const insertedTechnology = await techModel.insertMany(
    technologyArray
  );

  if (
    insertedEmp.length > 0 &&
    insertedTechnology.length > 0 &&
    insertedCompany.length > 0
  ) {
    return `Database setup is done:
            employeeDocumentsCount:${insertedEmp.length}
             companyDocumentsCount:${insertedCompany.length}
              technologyDocumentsCount:${insertedTechnology.length}
            `;
  } else {
    return "No data Inserted";
  }
};

exports.getAllEmployees = async ({offset,limit}) => {
  console.log("EMP DATA: getAllEmployees:");
  // could have simply returned ==>
  //return employeeArray

  // BUT :: simulating a server-side delay, returning a Promise that resolves after 1 sec!
  // return new Promise((res) => setTimeout(() => res(employeeArray), 1000));
  try {
    const empModel = await EmployeeModel();
    const employeeArray = await empModel.find({}).skip(offset).limit(limit);
    return employeeArray;
  } catch (err) {
    const error = new Error(
      "Cannot Fetch the Employee details. Please check the DB connection"
    );
    error.status = 500;
    throw error;
  }
};

exports.getEmployeeById = async (empId) => {
  console.log("EMP DATA: getEmployeeById:", empId);
  // return employeeArray.find(_ => _.id === empId)
  // simulating a server delay, returning a Promise that resolves after 1 sec!
  // const foundEmp = employeeArray.find((_) => _.id === empId);
  // return new Promise((res, rej) => {
  //   setTimeout(() => {
  //     foundEmp ? res(foundEmp) : rej(new Error("Employee details not Found"));
  //   }, 1000);
  // });
  try {
    const empModel = await EmployeeModel();
    const employeeArray = await empModel.findOne({
      id: empId,
    });
    if (employeeArray != null) {
      return employeeArray;
    } else {
      throw new Error("Employee Details not found");
    }
  } catch (err) {
    err.status = 500;
    throw err.message;
  }
};

exports.getEmployeesByCompanyId = async (companyId) => {
  console.log("EMP DATA: getEmployeesByCompanyId:", companyId);
  // return employeeArray.filter(_ => _.companyId === companyId);
  // simulating a server delay, returning a Promise that resolves after 1 secs!
  // return new Promise((res) =>
  //   setTimeout(
  //     () => res(employeeArray.filter((_) => _.companyId === companyId)),
  //     1000
  //   )
  // );
  try {
    const empModel = await EmployeeModel();
    const filteredEmp = await empModel.find({ companyId: companyId });
    console.log(filteredEmp);
    return filteredEmp

  } catch (err) {
    err.status = 500;

  }

};

exports.getEmployeesByTechnologyId = async (technologyId) => {
  console.log("EMP DATA: getEmployeesByTechnologyId:", technologyId);
  //return employeeArray.filter(_ => _.technologyIds.includes(technologyId));
  // return new Promise((res) =>
  //   setTimeout(
  //     () =>
  //       res(
  //         employeeArray.filter((_) => _.technologyIds.includes(technologyId))
  //       ),
  //     1000
  //   )
  // );
  try {
    const empModel = await EmployeeModel();
    const filteredEmp = await empModel.aggregate([
      {
        $project: {
          _id: 0,
          id: 1,
          firstName: 1,
          lastName: 1,
          jobLevel: 1,

          companyId: 1,
          technologyIds: {
            $filter: {
              input: "$technologyIds",
              as: "item",
              cond: { $eq: ["$$item", technologyId] },
            },
          },
        },
      },
      { $match: { technologyIds: { $size: 1 } } },
    ]);
    return filteredEmp

  } catch (err) {
    err.status = 500;
    throw err.message;
  }
};

exports.addANewEmployee = async (newEmpObj) => {
  console.log();
  console.log("EMP DATA: addANewEmployee:", newEmpObj);



  // employeeArray.push(newEmpObj);
  // console.log("Employee added!");
  // // to simulate a server delay
  // // return employeeArray.find(_ => _.id === newEmpObj.id);
  // return new Promise((res) =>
  //   setTimeout(
  //     () => res(employeeArray.find((_) => _.id === newEmpObj.id)),
  //     1000
  //   )
  // );

  try {
    const empModel = await EmployeeModel();
    const employeeArray = await empModel.find({});
    await isNewEmp(newEmpObj);

    newEmpObj.id = generateId("E", employeeArray);
    newEmpObj.companyId = "";
    newEmpObj.technologyIds = [];
    let employee = new empModel({
      id: newEmpObj.id,
      firstName: newEmpObj.firstName,
      lastName: newEmpObj.lastName,
      jobLevel: newEmpObj.jobLevel,
      companyId: newEmpObj.companyId,
      technologyIds: newEmpObj.technologyIds
    });
    const insertedEmp = await employee.save();
    console.log(insertedEmp);
    return insertedEmp
  }
  catch (err) {
    err.status = 500;
    throw err.message;
  }
};

async function isNewEmp(newEmpObj) {
  console.log("Checking: isNewEmp");
  // if (
  //   employeeArray.find(
  //     (_) =>
  //       _.firstName === newEmpObj.firstName && _.lastName === newEmpObj.lastName
  //   )
  // ) {
  //   console.log("No! couldn't add the employee");
  //   throw new Error("Employee already existing!");
  // }
  // console.log("Yes!");
  try {
    const empModel = await EmployeeModel();
    const employeeArray = await empModel.find({
      firstName: newEmpObj.firstName,
      lastName: newEmpObj.lastName
    })

    if (employeeArray.length > 0) {
      console.log("No! couldn't add the employee");
      throw new Error("Employee already existing!");
    } else {
      console.log("Yes!");
      return "Done!"
    }
  }
  catch (err) {
    err.status = 500;
    throw err;
  }
}

function generateId(strParam, dataArray) {
  return (
    strParam + (Math.max(...dataArray.map((_) => parseInt(_.id.substr(1)))) + 1)
  );
}

exports.mapTechEmpComp = async ({ techId, empId, compId }) => {
  console.log();
  console.log("EMP DATA: mapTechEmpComp:", techId, empId, compId);

  try {
    const empModel = await EmployeeModel();
    const techModel = await TechnologyModel();
    const cmpModel = await CompanyModel();
    if (techId && empId && compId) {
      throw new Error("Cannot work with all three entities together!");
    }
    // const foundEmp = employeeArray.find((_) => _.id === empId);
    const foundEmp = await empModel.findOne({ id: empId })
    if (!foundEmp) {
      throw new Error(
        "Cannot map Technologies and Companies, without an Employee!"
      );
    }
    if (
      (!await techModel.findOne({ id: techId })) &&
      (!await cmpModel.findOne({ id: compId }))
    ) {
      throw new Error("There is no technology or company matching this id!")
    }
    if (techId) {
      if (!foundEmp.technologyIds.includes(techId)) {
        // foundEmp.technologyIds.push(techId);
        let updatedemp = await empModel.update(
          { id: empId },
          { $addToSet: { technologyIds: techId } }
        );
        console.log(updatedemp);
      } else {
        throw new Error("techId is already mapped for this employee!");
      }
    } else if (compId) {
      // foundEmp.companyId = compId;
      let updatedemp = await empModel.update(
        { id: empId },
        { companyId: compId }
      );
      console.log(updatedemp);
    }
    const newEmp = await empModel.findOne({ id: empId });
    return newEmp
    // return new Promise((res) => setTimeout(() => res(foundEmp), 1000));
  }
  catch (err) {
    err.status = 500;
    throw err;
  }
};

exports.unMapTechEmpComp = async ({ techId, empId, compId }) => {
  console.log();
  console.log("EMP DATA: 666-555 UnMapTechEmpComp:", techId, empId, compId);

  try {
    const empModel = await EmployeeModel();
    const techModel = await TechnologyModel();
    const cmpModel = await CompanyModel();

    if (techId && empId && compId) {
      throw new Error("Cannot work with all three entities together!");
    }
    const foundEmp = await empModel.findOne({ id: empId });

    if (!foundEmp) {
      throw new Error(
        "Cannot Un-Map Technologies and Companies, without an Employee"
      );
    }

    if (
      !(await techModel.findOne({ id: techId })) &&
      !(await cmpModel.findOne({ id: compId }))
    ) {
      throw new Error("There is no technology or company matching this id!");
    }
    if (techId) {
      // foundEmp.technologyIds = foundEmp.technologyIds.filter((_) => _ !== techId);
      let updatedemp = await empModel.update(
        { id: empId },
        { $pull: { technologyIds: techId } }

      );
      console.log(updatedemp);
      if(updatedemp.nModified>0){
        console.log('Modified!');
      }else{
        throw new Error("TechId is already unmapped!")
      }
    } else if (compId) {
      let updatedemp = await empModel.update(
        { id: empId },
        { companyId: null }
      );
      console.log(updatedemp);
      // foundEmp.companyId = null;
    }
    return foundEmp;
    // return new Promise((res) => setTimeout(() => res(foundEmp), 1000));

  } catch (err) {
    err.status = 500;
    throw err;
  }
};
