const CompanyModel = require("./connection").getCompanyModel;
const EmployeeModel = require("./connection").getEmployeeModel;
exports.getAllCompanies = async ({offset,limit}) => {
  console.log("COMP DATA: getAllCompanies:");
  //return companyArray;
  // return new Promise(res => setTimeout(() => res(companyArray), 1000));

  try {
    const cmpModel = await CompanyModel();
    const companyArray = await cmpModel.find({}).skip(offset).limit(limit);
    return companyArray;
  } catch (err) {
    const error = new Error(
      "Cannot Fetch the Company details. Please check the DB connection"
    );
    error.status = 500;
    throw error;
  }

};

exports.getCompanyById = async (companyId) => {
  console.log("COMP DATA: getCompanyById:", companyId);
  //return companyArray.find(_ => _.id === companyId)
  // return new Promise((res) =>
  //   setTimeout(() => res(companyArray.find((_) => _.id === companyId)), 1000)
  // );
  try {
    const cmpModel = await CompanyModel();
    const companyArray = await cmpModel.findOne({
      id: companyId,
    });
    if (companyArray != null) {
      return companyArray;
    } else {
      throw new Error("Company Details not found");
    }
  } catch (err) {
    err.status = 500;
    throw err.message;
  }
};

exports.getCompaniesByTechnologyId = async (technologyId) => {
  console.log("COMP DATA: getCompaniesByTechnologyId:", technologyId);

  try {
    const empModel = await EmployeeModel();
    const employeeArray = await empModel.find({});
    const cmpModel = await CompanyModel();
    const companyArray = await cmpModel.find({});
    const companiesByTechnologyId = [
      ...new Set(
        employeeArray
          .filter((_) => _.technologyIds.includes(technologyId))
          .map((foundEmp) => foundEmp.companyId)
      ),
    ].map((aUniqueCompId) => companyArray.find((_) => _.id === aUniqueCompId));
    //return companiesByTechnologyId;
    // return new Promise((res) =>
    //   setTimeout(() => res(companiesByTechnologyId), 1000)
    // );
    return companiesByTechnologyId
  }
  catch (err) {
    const error = new Error(
      "Cannot Fetch the details. Please check the DB connection"
    );
    error.status = 500;
    throw error;
  }
};

exports.getACompanyByEmployeeId = async (empId) => {
  console.log("COMP DATA: getACompanyByEmployeeId:", empId);
  // const aCompanyByEmployeeId = companyArray.find(
  //   (_) => _.id === employeeArray.find((_) => _.id === empId).companyId
  // );
  // // return aCompanyByEmployeeId;
  // return new Promise((res) =>
  //   setTimeout(() => res(aCompanyByEmployeeId), 1000)
  // );

  try {
    const empModel = await EmployeeModel();
    const employeeArray = await empModel.findOne({ id: empId }).lean();
    const cmpModel = await CompanyModel();
    const companyArray = await cmpModel.findOne({ id: employeeArray.companyId });
    return companyArray;
  }
  catch (err) {
    const error = new Error(
      "Cannot Fetch the details. Please check the DB connection"
    );
    error.status = 500;
    throw error;
  }
};

exports.addANewCompany = async (newCompObj) => {
  console.log();
  console.log("COMP DATA: addANewCompany:", newCompObj);
  try {
    const cmpModel = await CompanyModel();
    const companyArray = await cmpModel.find({ name: newCompObj.name })
    await isNewComp(newCompObj);
    newCompObj.id = generateId("C", companyArray);
    // companyArray.push(newCompObj);
    // console.log("Company added!");
    // //return companyArray.find(_ => _.id === newCompObj.id);
    // return new Promise((res) =>
    //   setTimeout(
    //     () => res(companyArray.find((_) => _.id === newCompObj.id)),
    //     1000
    //   )
    // );
    let company = new cmpModel({
      id: newCompObj.id,
      name: newCompObj.name,
      description: newCompObj.description
    });
    const insertedcmp = await company.save();
    console.log(insertedcmp);
    return insertedcmp;

  }
  catch (err) {
    err.status = 500;
    throw err.message;
  }
};

async function isNewComp(newCompObj) {
  console.log("Checking: isNewComp");
  try {
    const cmpModel = await CompanyModel();
    const companyArray = await cmpModel.find({ name: newCompObj.name })

    // if (companyArray.find((_) => _.name === newCompObj.name)) {
    //   console.log("No! couldn't add the company");
    //   throw new Error("Company already existing!");
    // }
    // console.log("Yes!");
    if (companyArray.length > 0) {
      console.log("No! couldn't add the company");
      throw new Error("Company already existing!");
    } else {
      console.log("Yes!");
    }
  }
  catch (err) {
    err.status = 500;
    throw err;
  }
}

function generateId(strParam, dataArray) {
  return (
    strParam + (Math.max(...dataArray.map((_) => parseInt(_.id.substr(1)))) + 1)
  );
}
