// Importing the data sources

const TechnologyModel = require("./connection").getTechnologyModel;
const EmployeeModel = require("./connection").getEmployeeModel;

exports.getAllTechnologies = async () => {
  console.log("TECH DATA: getAllTechnologies:");
  //return technologyArray;
  // return new Promise((res) => setTimeout(() => res(technologyArray), 1000));
  try {
    const techModel = await TechnologyModel();
    const technologyArray = await techModel.find({});
    return technologyArray;
  } catch (err) {
    const error = new Error(
      "Cannot Fetch the Technology details. Please check the DB connection"
    );
    error.status = 500;
    throw error;
  }
};

exports.getTechnologyById = async (technologyId) => {
  console.log("TECH DATA: getTechnologyById:", technologyId);
  //return technologyArray.find(_ => _.id === technologyId)
  // return new Promise((res) =>
  //   setTimeout(
  //     () => res(technologyArray.find((_) => _.id === technologyId)),
  //     1000
  //   )
  // );

  try {
    const techModel = await TechnologyModel();

    const technologyObject = await techModel.findOne({ id: technologyId });
    if (technologyObject != null) {
      return technologyObject;
    } else {
      throw new Error("data not found");
    }
  } catch (err) {
    err.status = 500;
    throw err.message;
  }
};

exports.getTechnologiesByCompanyId = async (companyId) => {
  console.log("TECH DATA: getTechnologiesByCompanyId:", companyId);

  try {
    const empModel = await EmployeeModel();
    const employeeArray = await empModel.find({});
    const techModel = await TechnologyModel();
    const technologyArray = await techModel.find({});
    const uniqueTechArray = new Set();
    employeeArray
      .filter((_) => _.companyId === companyId)
      .forEach((empInCompany) =>
        empInCompany.technologyIds.forEach((techId) =>
          uniqueTechArray.add(techId)
        )
      );
    const technologiesByCompanyId = [...uniqueTechArray].map((_) =>
      technologyArray.find((__) => __.id === _)
    );
    return technologiesByCompanyId;
    // return new Promise((res) =>
    //   setTimeout(() => res(technologiesByCompanyId), 1000)
    // );
  } catch (err) {
    const error = new Error(
      "Cannot get technologies by CompanyId. Please check the DB collections"
    );
    error.status = 500;
    throw error;
  }
};

exports.getTechnologiesByEmployeeId = async (empId) => {
  console.log("TECH DATA: getTechnologiesByEmployeeId:", empId);
  // const technologiesByEmployeeId = employeeArray
  //   .find(_ => _.id === empId).technologyIds
  //   .map(_ => technologyArray.find(__ => __.id === _));
  // //return technologiesByEmployeeId;
  // return new Promise(res => setTimeout(() => res(technologiesByEmployeeId), 1000));
  try {
    const techModel = await TechnologyModel();
    const empModel = await EmployeeModel();
    const employeeArray = await empModel.findOne({ id: empId }).lean();
    const technologyArray = await techModel.find({});

    const technologiesByEmployeeId = employeeArray.technologyIds.map(
      (_) => technologyArray.filter((__) => __.id === _)[0]
    );
    return technologiesByEmployeeId;
  } catch (err) {
    const error = new Error(
      "Cannot get technologies by EmployeeId. Please check the DB collections"
    );
    error.status = 500;
    throw error;
  }
};

exports.addANewTechnology = async (newTechObj) => {
  console.log();
  console.log("TECH DATA: addANewTechnology:", newTechObj);
  try {
    const techModel = await TechnologyModel();
    const technologyArray = await techModel.find({});
    await isNewTech(newTechObj);
    newTechObj.id = generateId("T", technologyArray);
    // technologyArray.push(newTechObj);
    // console.log("Technology added!");
    // //return technologyArray.find(_ => _.id === newTechObj.id);
    // return new Promise((res) =>
    //   setTimeout(
    //     () => res(technologyArray.find((_) => _.id === newTechObj.id)),
    //     1000
    //   )
    // );
    let technology = new techModel({
      id: newTechObj.id,
      name: newTechObj.name,
      description: newTechObj.description,
    });
    const insertedTechnology = await technology.save();
    console.log(insertedTechnology);
    return insertedTechnology;
  } catch (err) {
    err.status = 500;
    throw err.message;
  }
};

async function isNewTech(newTechObj) {
  console.log("Checking: isNewTech");

  try {
    const techModel = await TechnologyModel();
    const technologyArray = await techModel.find({ name: newTechObj.name });
    // if (technologyArray.find((_) => _.name === newTechObj.name)) {
    //   console.log("No! couldn't add the technology");
    //   throw new Error("Technology already existing!");
    // }
    // console.log("Yes!");
    if (technologyArray.length > 0) {
      console.log("No! couldn't add the technology");
      throw new Error("Technology already existing!");
    } else {
      console.log("Yes!");
      return "Done!";
    }
  } catch (err) {
    err.status = 500;
    throw err;
  }
}

function generateId(strParam, dataArray) {
  return (
    strParam + (Math.max(...dataArray.map((_) => parseInt(_.id.substr(1)))) + 1)
  );
}
