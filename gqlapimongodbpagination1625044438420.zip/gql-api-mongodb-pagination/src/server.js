const bodyParser = require('body-parser')
const cors = require('cors')
const express = require('express')
const port = process.env.PORT || 4000
const app = express()

// 0. Register Express middlewares
app.use(bodyParser.json(), cors())

// 0. Setting up GraphQL
const { ApolloServer } = require('apollo-server-express');

const typeDefs = require("./schema");
const resolvers = require("./resolver");


// 4. Initialize the ApolloExpressServer 
const server = new ApolloServer({ typeDefs, resolvers });
server.applyMiddleware({ app });

// Already present app.listen() 
app.listen({ port }, () => {
  console.log(`TEC GQL Server ready at http://localhost:${port}${server.graphqlPath}`)
});