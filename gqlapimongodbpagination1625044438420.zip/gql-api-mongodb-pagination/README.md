npm init --yes
## Express Mongoose and Node related
npm i --save axios cors express mongoose nodemon

## Apollo Server Related
npm i --save apollo-server-express graphql 
